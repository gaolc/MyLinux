#!/bin/bash
#Branch1 old 分支
#Branch2 new 分支
if [ ! $# -eq 2 ];then
echo "info: sh gitDiff.sh {Branch_old} {Branch_new}"
exit 0
fi
Branch1="release_$1"
Branch2="release_$2"
echo $Branch1
echo $Branch2
cat ./list | while read LIST
do
rm -rf $LIST
git clone -b $Branch1 http://gitlab.scm.cfets.com/TS/"$LIST.git"
cd $LIST 
echo $LIST
git checkout $Branch1
git checkout $Branch2
git diff --stat $Branch1 | grep -v "test" > ../"$LIST.txt"
cd ..

done


